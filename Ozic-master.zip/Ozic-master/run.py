from service import createApp
from service.model import  Test_Process

app = createApp()

if __name__ == '__main__':
    app.run(debug=True)